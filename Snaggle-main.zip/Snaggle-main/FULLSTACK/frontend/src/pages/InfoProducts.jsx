import React from "react";
import Layout from "./Layout";
import InfoProduct from "../components/InfoProduct";
const InfoProducts = () => {
  return (
    <Layout>
      <InfoProduct />
    </Layout>
  );
};

export default InfoProducts;

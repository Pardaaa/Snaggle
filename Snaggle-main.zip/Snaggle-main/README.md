# Snaggle
Anggota Kelompok : <br>
2272009_Charles Winata <br>
2272035_Nabilla Octaviani Rusmayanto <br>
2272039_Nathan Raphael Pardamean Hutagalung <br>
2272046_Immanuel Christian <br>
Project Pemrograman Terapan
